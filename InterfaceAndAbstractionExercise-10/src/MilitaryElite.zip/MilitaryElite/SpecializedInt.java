package MilitaryElite;

public interface SpecializedInt extends PrivateInt{
    String getCorp();
}
