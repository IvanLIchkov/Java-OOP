package MilitaryElite;

public interface Getbale {
    String getFirstname();
    String getLastName();
    int getId();
}
