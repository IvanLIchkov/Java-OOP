package MilitaryElite;

import java.util.List;

public interface EngineerInt extends SpecializedInt{
    List<Repair> getRepairs();
}
