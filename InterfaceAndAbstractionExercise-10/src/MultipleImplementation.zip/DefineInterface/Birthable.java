package DefineInterface;

public interface Birthable {
    String getBirthDate();
}
