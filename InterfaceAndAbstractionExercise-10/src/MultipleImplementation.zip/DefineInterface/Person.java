package DefineInterface;

public interface Person {
    String getName();
    int getAge();
}
