package DefineInterface;

public interface Identifiable {
    String getId();
}
