package FoodShortage;

public interface Identifiable {
    String getId();
}
