package RandomArrayList;

public class MyStack {
}
