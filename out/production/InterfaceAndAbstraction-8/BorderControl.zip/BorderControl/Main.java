package BorderControl;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        String command= scan.nextLine();
        Map<String, Identifiable> nameAndId=new HashMap<>();
        while (!command.equals("End")){
            String[] commands=command.split("\\s+");
            String name=commands[0];
            if (commands.length==3){
                int age=Integer.parseInt(commands[1]);
                String id=commands[2];
                Identifiable citizen=new Citizen(name,age,id);
                nameAndId.put(name, citizen);
            }else{
                String id= commands[1];
                Identifiable robot=new Robot(id,name);
                nameAndId.put(name, robot);
            }
            command= scan.nextLine();
        }
        String end= scan.nextLine();
        nameAndId.entrySet().stream()
                .filter(e->e.getValue().getId().endsWith(end))
                .forEach(e-> System.out.println(e.getValue().getId()));
    }
}
