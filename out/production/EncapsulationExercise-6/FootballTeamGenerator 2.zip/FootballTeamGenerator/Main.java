package FootballTeamGenerator;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        String command= scan.nextLine();
        List<Team> teams=new ArrayList<>();
        while (!command.equals("END")){
            try {
                String[] tokens = command.split(";");
                String teamName = tokens[1];
                switch (tokens[0]) {
                    case "Team":
                        String name = tokens[1];
                        Team team = new Team(name);
                        teams.add(team);
                        break;
                    case "Add":
                        if (teams.stream().noneMatch(e -> e.getName().equals(teamName))) {
                            System.out.printf("Team %s does not exist.", teamName);
                        } else {
                            String playerName = tokens[2];
                            int endurance = Integer.parseInt(tokens[3]);
                            int sprint = Integer.parseInt(tokens[4]);
                            int dribble = Integer.parseInt(tokens[5]);
                            int passing = Integer.parseInt(tokens[6]);
                            int shooting = Integer.parseInt(tokens[7]);
                            Player player = new Player(playerName, endurance, sprint, dribble, passing, shooting);
                            teams.stream().filter(t -> t.getName().equals(teamName)).forEach(t -> t.addPlayer(player));
                        }
                        break;
                    case "Remove":
                        String playerName = tokens[2];
                        teams.stream().filter(t -> t.getName().equals(teamName)).forEach(t -> t.removePlayer(playerName));
                        break;
                    case "Rating":
                        if (teams.stream().noneMatch(e -> e.getName().equals(teamName))) {
                            System.out.printf("Team %s does not exist.", teamName);
                        } else {
                             double sum = teams.stream().filter(t -> t.getName().equals(teamName)).mapToDouble(Team::getRating).sum();
                             if (Double.isNaN(sum)){
                                 sum=0;
                             }
                            System.out.printf("%s - %d",teamName, Math.round(sum));
                        }
                        break;
                }
            }catch (IllegalArgumentException e){
                System.out.println(e.getMessage());
            }
            command= scan.nextLine();
        }
    }
}
