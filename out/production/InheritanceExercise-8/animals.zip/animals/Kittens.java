package animals;

public class Kittens extends Cat{
    private static final String KITTENS_GENDER="Female";

    public Kittens(String name, int age) {
        super(name, age, KITTENS_GENDER);
    }

    @Override
    public void produceSound() {
        System.out.println("Meow");
    }
}
