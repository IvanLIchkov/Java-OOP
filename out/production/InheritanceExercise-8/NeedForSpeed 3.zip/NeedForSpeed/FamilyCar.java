package NeedForSpeed;

public class FamilyCar extends Car{

    public FamilyCar(double fuel, int horsePower) {
        super(fuel, horsePower);
    }

    @Override
    public void Drive(double kilometers) {
        super.Drive(kilometers);
    }
}
