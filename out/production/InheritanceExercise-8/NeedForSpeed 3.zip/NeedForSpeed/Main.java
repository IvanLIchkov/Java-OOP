package NeedForSpeed;

public class Main {
    public static void main(String[] args) {
        SportCar sportCar= new SportCar(9,150);
        sportCar.Drive(1);
        System.out.println(sportCar.getFuel());
    }
}
