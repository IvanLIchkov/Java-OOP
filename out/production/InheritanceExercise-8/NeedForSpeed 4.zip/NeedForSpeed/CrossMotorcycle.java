package NeedForSpeed;

public class CrossMotorcycle extends Motorcycle{
    public CrossMotorcycle(double fuel, int horsePower) {
        super(fuel, horsePower);
    }

    @Override
    public void Drive(double kilometers) {
        super.Drive(kilometers);
    }
}
