package NeedForSpeed;

public class Car extends Vehicle{
    public Car(double fuel, int horsePower) {
        super(fuel, horsePower);
        super.setFuelConsumption(3);
    }

    @Override
    public void Drive(double kilometers) {
        super.Drive(kilometers);
    }
}
