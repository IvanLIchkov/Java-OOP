package Telephony;

import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        List<String> numbers= Arrays.stream(scan.nextLine().split("\\s+")).collect(Collectors.toList());
        List<String> urls= Arrays.stream(scan.nextLine().split("\\s+")).collect(Collectors.toList());
        Smartphone smartphone=new Smartphone(numbers,urls);
        smartphone.getNumbers().stream()
                .forEach(n-> {
                    if (n.matches("[0-9]+")){
                        System.out.println(smartphone.call()+n);
                    }else{
                        System.out.println("Invalid number!" );
                    }
                });
        smartphone.getUrls().stream()
                .forEach(url->{
                    if (url.matches(".*\\d.*")){
                        System.out.println("Invalid URL!");
                    }else{
                        System.out.println(smartphone.browse()+url+"!");
                    }
                });
    }
}
