package Telephony;

public interface Browsable extends Callable {
    String browse();
}
