package MilitaryElite;

public interface SpyInt extends Getbale {
    int getCodeNumber();
}
