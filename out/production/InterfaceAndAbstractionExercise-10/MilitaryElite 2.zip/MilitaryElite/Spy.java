package MilitaryElite;

public class Spy extends SoliderImpl implements SpyInt{
    private int codeNumber;

    public Spy(int id, String firstName, String lastName, int codeNumber) {
        super(id, firstName, lastName);
        this.codeNumber = codeNumber;
    }

    @Override
    public String toString() {
        return String.format("Name: %s %s Id: %d%n" +
                "Code Number: %d%n",getFirstname(),getLastName(),getId(),getCodeNumber());
    }

    @Override
    public int getCodeNumber() {
        return codeNumber;
    }
}
