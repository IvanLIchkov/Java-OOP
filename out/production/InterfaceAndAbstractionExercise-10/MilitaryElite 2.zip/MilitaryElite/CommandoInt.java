package MilitaryElite;

import java.util.List;

public interface CommandoInt extends SpecializedInt{
    List<Mission> getMissions();
}
