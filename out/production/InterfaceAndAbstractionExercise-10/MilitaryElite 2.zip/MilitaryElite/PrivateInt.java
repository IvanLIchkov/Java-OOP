package MilitaryElite;

public interface PrivateInt extends Getbale{
    double getSalary();
}
