package MilitaryElite;

public interface SpyInt extends Getbale {
    String getCodeNumber();
}
