package WildFarm;

public interface AnimalInterface {
    void makeSound();
    void eat(Food food);
}
