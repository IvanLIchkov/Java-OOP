package Vehicles;

public interface VehicleInterface {

     void refuel(double litres);
     void drive(double km);

}
