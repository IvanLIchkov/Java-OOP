package spaceStation.core;

public interface Engine extends Runnable {
}
