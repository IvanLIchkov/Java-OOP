package CardSuit;

public enum Suits {
    CLUBS,
    DIAMONDS,
    HEARTS,
    SPADES;
}
