import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;

public class Main {
    public static void main(String[] args) throws ClassNotFoundException, NoSuchMethodException, InvocationTargetException, InstantiationException, IllegalAccessException {
         Class clazz= Class.forName("Reflection");

        System.out.println(clazz);

        Class superclass = clazz.getSuperclass();
        System.out.println(superclass);

        Class[] interfaces = clazz.getInterfaces();
        for (Class anInterface : interfaces) {
            System.out.println(anInterface);
        }

        Constructor constructor = clazz.getDeclaredConstructor();
        Object newInstance = constructor.newInstance();

        System.out.println(newInstance);

    } 
}